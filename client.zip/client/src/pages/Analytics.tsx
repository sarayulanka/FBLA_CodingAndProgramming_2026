import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, BarChart3, Download, Star, Heart, Building2, MessageSquare } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";

const COLORS = ["#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#EC4899", "#06B6D4", "#F97316", "#84CC16", "#6366F1"];

type DateRange = "7d" | "30d" | "all";

export default function Analytics() {
  const [dateRange, setDateRange] = useState<DateRange>("30d");
  const [, setLocation] = useLocation();

  const { data: summary, isLoading: summaryLoading } = trpc.analytics.summary.useQuery({ dateRange });
  const { data: reviewsByDate, isLoading: reviewsLoading } = trpc.analytics.reviewsByDate.useQuery({ dateRange });
  const { data: categoryData, isLoading: categoryLoading } = trpc.analytics.categoryBreakdown.useQuery();
  const { data: topRated } = trpc.analytics.topRated.useQuery({ limit: 10 });

  const handleExportCSV = () => {
    if (!reviewsByDate || !categoryData) return;

    let csv = "Section,Field,Value\n";

    // Summary
    if (summary) {
      csv += `Summary,Total Reviews,${summary.totalReviews}\n`;
      csv += `Summary,Total Businesses,${summary.totalBusinesses}\n`;
      csv += `Summary,Total Favorites,${summary.totalFavorites}\n`;
      csv += `Summary,Average Rating,${summary.avgRating}\n`;
    }

    csv += "\nDate,Review Count\n";
    for (const row of reviewsByDate) {
      csv += `${row.date},${row.count}\n`;
    }

    csv += "\nCategory,Favorite Count\n";
    for (const row of categoryData) {
      csv += `${row.category},${row.count}\n`;
    }

    if (topRated) {
      csv += "\nBusiness,Rating,Reviews\n";
      for (const biz of topRated) {
        csv += `"${biz.name}",${(biz.rating / 10).toFixed(1)},${biz.reviewCount}\n`;
      }
    }

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bizbloom-analytics-${dateRange}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-12">
        <div className="container">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-gray-300 hover:text-white mb-4 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="w-10 h-10" />
            <h1 className="text-4xl font-bold">Analytics</h1>
          </div>
          <p className="text-gray-300">
            Community activity insights and reports
          </p>
        </div>
      </div>

      <div className="container py-8">
        {/* Controls */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <label htmlFor="date-range" className="text-sm font-medium text-gray-700">
              Date Range
            </label>
            <Select value={dateRange} onValueChange={(v: DateRange) => setDateRange(v)}>
              <SelectTrigger className="w-48" id="date-range">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="all">All time</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleExportCSV} variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {summaryLoading ? (
            [...Array(4)].map((_, i) => (
              <Card key={i}><CardContent className="pt-6"><Skeleton className="h-16 w-full" /></CardContent></Card>
            ))
          ) : (
            <>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <MessageSquare className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{summary?.totalReviews ?? 0}</p>
                      <p className="text-sm text-gray-500">Total Reviews</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <Building2 className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{summary?.totalBusinesses ?? 0}</p>
                      <p className="text-sm text-gray-500">Businesses</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-red-100 rounded-lg">
                      <Heart className="w-6 h-6 text-red-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{summary?.totalFavorites ?? 0}</p>
                      <p className="text-sm text-gray-500">Total Favorites</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-yellow-100 rounded-lg">
                      <Star className="w-6 h-6 text-yellow-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{summary?.avgRating ?? 0}</p>
                      <p className="text-sm text-gray-500">Avg Rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Review Activity Over Time */}
          <Card>
            <CardHeader>
              <CardTitle>Review Activity</CardTitle>
              <CardDescription>Reviews submitted over time</CardDescription>
            </CardHeader>
            <CardContent>
              {reviewsLoading ? (
                <Skeleton className="h-64 w-full" />
              ) : reviewsByDate && reviewsByDate.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={reviewsByDate}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Line type="monotone" dataKey="count" stroke="#3B82F6" strokeWidth={2} name="Reviews" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-gray-400">
                  No review data for this period
                </div>
              )}
            </CardContent>
          </Card>

          {/* Category Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Favorites by Category</CardTitle>
              <CardDescription>Most favorited business categories</CardDescription>
            </CardHeader>
            <CardContent>
              {categoryLoading ? (
                <Skeleton className="h-64 w-full" />
              ) : categoryData && categoryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={categoryData}
                      dataKey="count"
                      nameKey="category"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      label={({ category, count }) => `${category} (${count})`}
                    >
                      {categoryData.map((_, index) => (
                        <Cell key={index} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-gray-400">
                  No category data yet
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Top Rated Businesses Table */}
        <Card>
          <CardHeader>
            <CardTitle>Top Rated Businesses</CardTitle>
            <CardDescription>Highest rated businesses in the community</CardDescription>
          </CardHeader>
          <CardContent>
            {topRated && topRated.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-600">#</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Business</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">City</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Rating</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Reviews</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topRated.map((biz: any, i: number) => (
                      <tr key={biz.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4 text-gray-500">{i + 1}</td>
                        <td className="py-3 px-4 font-medium">{biz.name}</td>
                        <td className="py-3 px-4 text-gray-600">{biz.city || "—"}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            {(biz.rating / 10).toFixed(1)}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-gray-600">{biz.reviewCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-12 text-center text-gray-400">
                No businesses data yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
