import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageSquare, ArrowLeft } from "lucide-react";
import { getLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";

export default function Reviews() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Sign in Required</CardTitle>
            <CardDescription>
              You need to be signed in to write reviews.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button asChild className="w-full">
              <a href={getLoginUrl()}>Sign In</a>
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-12">
        <div className="container">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-purple-200 hover:text-white mb-4 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
          <h1 className="text-4xl font-bold mb-2">Write a Review</h1>
          <p className="text-purple-100">
            Share your experience with the community
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container py-12">
        <Card className="max-w-2xl mx-auto text-center p-8">
          <MessageSquare className="w-16 h-16 mx-auto text-purple-600 mb-4" />
          <CardHeader>
            <CardTitle>How to Write a Review</CardTitle>
            <CardDescription className="text-base leading-relaxed">
              To write a review, search for a business on the{" "}
              <Link href="/" className="text-blue-600 hover:underline font-medium">
                home page
              </Link>{" "}
              and click on it to open the business details. You'll find a "Write a Review" button there.
            </CardDescription>
          </CardHeader>
          <CardFooter className="justify-center">
            <Button onClick={() => setLocation("/")} size="lg">
              Go to Home Page
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
